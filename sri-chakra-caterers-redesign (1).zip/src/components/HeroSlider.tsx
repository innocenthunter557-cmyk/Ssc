"use client";

import React, { useState, useEffect, useRef } from "react";
import Link from "next/link";
import Image from "next/image";
import { ChevronLeft, ChevronRight, Sparkles, UtensilsCrossed } from "lucide-react";

interface Slide {
  id: number;
  tag: string;
  headline: string;
  headlineTe: string;
  description: string;
  descriptionTe: string;
  imageUrl: string;
  menuLink: string;
  badge: string;
}

const slides: Slide[] = [
  {
    id: 1,
    tag: "SIGNATURE EXPERIENCE",
    headline: "The Royal Arati Aaku Feast",
    headlineTe: "రాజసం ఉట్టిపడే అరిటాకు విందు",
    description: "Experience the soulful warmth of authentic South Indian hospitality served on fresh green banana leaves with pure Telugu culinary heritage.",
    descriptionTe: "తాజా పచ్చని అరటి ఆకుపై స్వచ్ఛమైన తెలుగు సంప్రదాయ పిండివంటలు మరియు ఆతిథ్య మాధుర్యం.",
    imageUrl: "/images/arati-aaku-feast.jpg",
    menuLink: "/menu/veg_grand_399",
    badge: "Traditional Arati Aaku",
  },
  {
    id: 2,
    tag: "WEDDINGS & CELEBRATIONS",
    headline: "Blessed Occasions. Unforgettable Banquets.",
    headlineTe: "శుభకార్యాలు • మధురమైన విందు భోజనాలు",
    description: "From traditional Kalyana Mandapams to grand celebration halls, we craft sacred, deliciously memorable wedding catering across Hyderabad.",
    descriptionTe: "కళ్యాణ వేదికల నుండి గ్రాండ్ రిసెప్షన్ల వరకు, హైదరాబాద్ నలుమూలలా పరిపూర్ణమైన కేటరింగ్ సేవలు.",
    imageUrl: "/images/wedding-catering-setup.jpg",
    menuLink: "/menu",
    badge: "Hyderabad's Trusted Caterers",
  },
  {
    id: 3,
    tag: "PURE VEGETARIAN DELIGHT",
    headline: "Sacred Pure Vegetarian Grand Menus",
    headlineTe: "పరిశుద్ధమైన ప్యూర్ వెజిటేరియన్ మెనూలు",
    description: "Prepared with premium Gold Drop Oil & Vijaya Ghee. Over 20 authentic courses, custom starter selections, and traditional royal sweets.",
    descriptionTe: "విజయ నెయ్యి, గోల్డ్ డ్రాప్ ఆయిల్‌తో తయారుచేసిన ప్రామాణికమైన వంటకాలు మరియు నోరూరించే స్వీట్లు.",
    imageUrl: "/images/veg-grand-feast.jpg",
    menuLink: "/menu/veg_special_280",
    badge: "Starting ₹280 / ₹399",
  },
  {
    id: 4,
    tag: "HYDERABADI SPECIALITY",
    headline: "Authentic Dum Biryani & Non-Veg Banquets",
    headlineTe: "అసలైన హైదరాబాదీ దమ్ బిర్యానీ విందు",
    description: "Fragrant saffron Mutton Dum Biryani, Chicken 65, rich Mirchi Ka Salan, Apollo Fish, and all-inclusive service for joyous celebrations.",
    descriptionTe: "ఘుమఘుమలాడే మటన్ దమ్ బిర్యానీ, చికెన్ 65, మిర్చి కా సాలన్ మరియు అద్భుతమైన వడ్డన.",
    imageUrl: "/images/hyderabadi-biryani-feast.jpg",
    menuLink: "/menu/nonveg_standard_399",
    badge: "Budget, Standard & Silver",
  },
];

export default function HeroSlider() {
  const [current, setCurrent] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef<number | null>(null);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [isPaused]);

  const prevSlide = () => {
    setCurrent((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  const nextSlide = () => {
    setCurrent((prev) => (prev + 1) % slides.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (diff > 50) nextSlide();
    if (diff < -50) prevSlide();
    touchStartX.current = null;
  };

  const slide = slides[current];

  return (
    <div
      className="relative w-full h-[580px] sm:h-[640px] lg:h-[720px] overflow-hidden bg-[#183D2B] text-[#FFF9EA]"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Background Images with Crossfade */}
      {slides.map((s, index) => (
        <div
          key={s.id}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            index === current ? "opacity-100 scale-100" : "opacity-0 pointer-events-none scale-105"
          } transition-transform duration-[6000ms]`}
        >
          <Image
            src={s.imageUrl}
            alt={s.headline}
            fill
            priority={index === 0}
            className="object-cover object-center"
          />
          {/* Deep traditional gradient overlays */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#183D2B]/95 via-[#183D2B]/75 to-transparent sm:w-2/3" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#183D2B] via-transparent to-[#183D2B]/40" />
        </div>
      ))}

      {/* Decorative Traditional Toran at top */}
      <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-[#C49A43] via-[#FFF9EA] to-[#C49A43] opacity-60 z-20" />

      {/* Content Container */}
      <div className="relative z-20 max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
        <div className="max-w-2xl space-y-4 sm:space-y-6 animate-fadeIn">
          {/* Tag and Badge */}
          <div className="flex items-center gap-3 flex-wrap">
            <span className="px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase bg-[#C49A43] text-[#183D2B] shadow-sm">
              {slide.tag}
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold tracking-wide bg-white/10 text-[#F3E7C9] backdrop-blur-sm border border-white/20">
              {slide.badge}
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="font-serif-brand text-3xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] text-[#FFF9EA] drop-shadow-md">
            {slide.headline}
          </h1>

          {/* Telugu Headline Accent */}
          <p className="text-base sm:text-lg text-[#C49A43] font-serif tracking-wide">
            {slide.headlineTe}
          </p>

          {/* Description */}
          <p className="text-sm sm:text-base lg:text-lg text-[#F3E7C9]/90 leading-relaxed font-sans max-w-xl">
            {slide.description}
          </p>

          {/* CTAs */}
          <div className="pt-2 sm:pt-4 flex items-center gap-4 flex-wrap">
            <Link
              href="/book"
              className="px-6 py-3.5 rounded-full bg-gradient-to-r from-[#C49A43] to-[#A37B2E] text-[#183D2B] font-bold text-sm sm:text-base shadow-xl hover:shadow-2xl hover:scale-105 transition-all flex items-center gap-2 group"
            >
              <Sparkles className="w-4 h-4 text-[#183D2B] group-hover:rotate-12 transition-transform" />
              <span>Book Catering Wizard</span>
            </Link>

            <Link
              href={slide.menuLink}
              className="px-6 py-3.5 rounded-full bg-white/10 hover:bg-white/20 text-[#FFF9EA] font-semibold text-sm sm:text-base backdrop-blur-sm border border-white/30 transition-all flex items-center gap-2"
            >
              <UtensilsCrossed className="w-4 h-4 text-[#C49A43]" />
              <span>Explore Menus</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Manual Arrow Controls */}
      <button
        onClick={prevSlide}
        aria-label="Previous slide"
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#183D2B]/70 hover:bg-[#C49A43] text-[#FFF9EA] hover:text-[#183D2B] backdrop-blur-sm border border-[#C49A43]/40 flex items-center justify-center transition-all shadow-md"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button
        onClick={nextSlide}
        aria-label="Next slide"
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-[#183D2B]/70 hover:bg-[#C49A43] text-[#FFF9EA] hover:text-[#183D2B] backdrop-blur-sm border border-[#C49A43]/40 flex items-center justify-center transition-all shadow-md"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Bottom Pagination Indicators */}
      <div className="absolute bottom-6 inset-x-0 z-20 flex justify-center items-center gap-2.5">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrent(idx)}
            aria-label={`Go to slide ${idx + 1}`}
            className={`transition-all duration-300 rounded-full ${
              idx === current
                ? "w-8 h-2.5 bg-[#C49A43] shadow-md"
                : "w-2.5 h-2.5 bg-white/40 hover:bg-white/70"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
