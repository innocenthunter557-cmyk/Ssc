"use client";

import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Sparkles, Info, CheckCircle2, ChevronRight } from "lucide-react";

interface LeafItem {
  id: number;
  nameEn: string;
  nameTe: string;
  category: string;
  x: string; // percentage position on leaf
  y: string;
  servingOrder: string;
  description: string;
}

const leafDishes: LeafItem[] = [
  {
    id: 1,
    nameEn: "Steaming Rice & Vijaya Ghee",
    nameTe: "వేడి అన్నం & నెయ్యి",
    category: "Centerpiece / Staple",
    x: "50%",
    y: "50%",
    servingOrder: "Served at the heart of the leaf after guest is seated.",
    description: "Hot aromatic Telugu rice topped with pure melted Vijaya ghee and mudda pappu for the divine first morsel.",
  },
  {
    id: 2,
    nameEn: "Andhra Tomato Pappu",
    nameTe: "టొమాటో పప్పు",
    category: "Traditional Dal",
    x: "48%",
    y: "32%",
    servingOrder: "Poured generously over the first course of rice.",
    description: "Slow-cooked toor dal tempered with mustard seeds, cumin, garlic, and fresh curry leaves.",
  },
  {
    id: 3,
    nameEn: "Guttivankaya Masala",
    nameTe: "గుత్తివంకాయ మసాలా",
    category: "Signature Curry",
    x: "68%",
    y: "28%",
    servingOrder: "Placed in upper right quadrant of the leaf.",
    description: "Tender brinjals stuffed with roasted peanut, sesame, and rich Telugu spice blend.",
  },
  {
    id: 4,
    nameEn: "Piping Hot Sambar",
    nameTe: "సాంబార్",
    category: "Second Course Gravy",
    x: "72%",
    y: "48%",
    servingOrder: "Served warm for the second helping of rice.",
    description: "Fragrant lentil stew simmered with drumsticks, shallots, pumpkin, and freshly ground sambar masala.",
  },
  {
    id: 5,
    nameEn: "Avakaya Mango Pickle & Chutney",
    nameTe: "ఆవకాయ & రోటీ పచ్చడి",
    category: "Spicy Condiments",
    x: "82%",
    y: "65%",
    servingOrder: "Served in small dollops along the leaf margin.",
    description: "Traditional sun-aged spicy Andhra avakaya made with mustard powder and pure gingelly oil.",
  },
  {
    id: 6,
    nameEn: "Crispy Papad & Fryums",
    nameTe: "అప్పడం & ఫ్రైయమ్స్",
    category: "Crunchy Side",
    x: "62%",
    y: "75%",
    servingOrder: "Placed near the right hand for easy crunching.",
    description: "Golden sun-dried urad dal papad fried crisp in fresh groundnut oil.",
  },
  {
    id: 7,
    nameEn: "Mirchi Bajji & Veg 65",
    nameTe: "మిర్చి బజ్జి & గోబీ 65",
    category: "Hot Snacks",
    x: "42%",
    y: "78%",
    servingOrder: "Freshly fried and served hot onto the leaf.",
    description: "Plump Bhavnagri chillies dipped in seasoned besan batter and fried golden.",
  },
  {
    id: 8,
    nameEn: "Gulab Jamun & Payasam",
    nameTe: "గులాబ్ జామూన్ & పాయసం",
    category: "Auspicious Sweets",
    x: "24%",
    y: "68%",
    servingOrder: "Placed on lower left corner to begin and conclude auspiciously.",
    description: "Melt-in-mouth milk solids soaked in rose cardamom syrup, accompanied by golden semiya payasam.",
  },
  {
    id: 9,
    nameEn: "Thick Fresh Curd (Perugu)",
    nameTe: "మీగడ పెరుగు",
    category: "Cooling Conclusion",
    x: "22%",
    y: "45%",
    servingOrder: "Served as the final course to cool and satisfy digestion.",
    description: "Rich farm-fresh buffalo curd served chilled with a hint of mango pickle.",
  },
  {
    id: 10,
    nameEn: "Pulihora (Tamarind Rice)",
    nameTe: "గుడి పులిహోర",
    category: "Prasadam Flavoured Rice",
    x: "28%",
    y: "28%",
    servingOrder: "Served alongside pooris and curries.",
    description: "Aromatic turmeric-tinged rice tempered with peanuts, green chillies, ginger, and sour tamarind paste.",
  },
];

export default function AratiAakuSection() {
  const [activeDish, setActiveDish] = useState<LeafItem>(leafDishes[0]);

  return (
    <section id="arati-aaku" className="py-16 sm:py-24 bg-[#183D2B] text-[#FFF9EA] relative overflow-hidden">
      {/* Background kolam and leaf gradient */}
      <div className="absolute inset-0 kolam-pattern opacity-10 pointer-events-none" />
      <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-[#557A3B]/20 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-[#C49A43]/15 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#557A3B]/30 border border-[#C49A43]/40 text-[#F3E7C9] text-xs sm:text-sm font-semibold tracking-wider uppercase">
            <span className="w-2 h-2 rounded-full bg-[#C49A43] animate-pulse" />
            <span>Sri Chakra Signature Tradition</span>
          </div>

          <h2 className="font-serif-brand text-3xl sm:text-5xl lg:text-5xl font-bold text-[#FFF9EA] tracking-tight">
            The Tradition of Arati Aaku
          </h2>

          <p className="font-serif text-xl sm:text-2xl text-[#C49A43] italic">
            అరిటాకు సంప్రదాయ భోజనం
          </p>

          <p className="text-base sm:text-lg text-[#F3E7C9]/90 font-sans leading-relaxed">
            &ldquo;Some meals are more than food. They are a tradition served with love. Experience the warmth of authentic South Indian hospitality on a fresh banana leaf.&rdquo;
          </p>
        </div>

        {/* Visual Interactive Banana Leaf Showcase */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center mb-16">
          {/* Leaf Interactive Diagram (7 Cols) */}
          <div className="lg:col-span-7 bg-[#122D20] p-4 sm:p-6 rounded-3xl border-2 border-[#C49A43]/30 shadow-2xl relative">
            <div className="flex items-center justify-between mb-3 text-xs text-[#F3E7C9]/80">
              <span className="flex items-center gap-1.5 text-[#C49A43] font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Tap any dish marker on the leaf to explore</span>
              </span>
              <span className="hidden sm:inline bg-[#557A3B]/30 px-2 py-0.5 rounded text-[11px]">
                Authentic Serving Sequence
              </span>
            </div>

            {/* Banana Leaf Canvas with Unfolding Animation */}
            <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden shadow-inner border border-[#557A3B]/40 animate-leaf-unfold">
              <Image
                src="/images/arati-aaku-feast.jpg"
                alt="Traditional South Indian Arati Aaku Feast on fresh banana leaf"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-[#183D2B]/30 backdrop-brightness-95" />

              {/* Interactive Hotspots over the leaf */}
              {leafDishes.map((dish) => {
                const isSelected = activeDish.id === dish.id;
                return (
                  <button
                    key={dish.id}
                    onClick={() => setActiveDish(dish)}
                    style={{ left: dish.x, top: dish.y }}
                    aria-label={`Inspect ${dish.nameEn}`}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group transition-all duration-300 focus:outline-none ${
                      isSelected ? "scale-125 z-30" : "hover:scale-110"
                    }`}
                  >
                    <span className="relative flex h-7 w-7 sm:h-8 sm:w-8 items-center justify-center">
                      <span
                        className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                          isSelected ? "bg-[#C49A43]" : "bg-[#557A3B]"
                        }`}
                      />
                      <span
                        className={`relative inline-flex rounded-full h-6 w-6 sm:h-7 sm:w-7 items-center justify-center text-[10px] sm:text-xs font-bold text-[#183D2B] shadow-lg border-2 ${
                          isSelected
                            ? "bg-[#C49A43] border-white scale-110"
                            : "bg-[#FFF9EA] border-[#C49A43] group-hover:bg-[#C49A43]"
                        }`}
                      >
                        {dish.id}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>

            <p className="mt-3 text-center text-xs text-[#F3E7C9]/60 italic">
              * Natural chlorophyll in fresh banana leaves releases delicate aroma and aids healthy digestion when hot meals are served.
            </p>
          </div>

          {/* Active Dish Details Panel (5 Cols) */}
          <div className="lg:col-span-5 bg-[#122D20] p-6 sm:p-8 rounded-3xl border-2 border-[#C49A43]/40 shadow-xl space-y-6">
            <div className="flex items-center justify-between border-b border-[#C49A43]/30 pb-4">
              <div>
                <span className="text-xs uppercase font-bold tracking-wider text-[#C49A43] block">
                  Course #{activeDish.id} • {activeDish.category}
                </span>
                <h3 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#FFF9EA] mt-1">
                  {activeDish.nameEn}
                </h3>
                <span className="text-base text-[#C49A43] font-serif block mt-0.5">
                  {activeDish.nameTe}
                </span>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#C49A43]/20 border border-[#C49A43] flex items-center justify-center text-xl font-bold text-[#C49A43]">
                #{activeDish.id}
              </div>
            </div>

            <div className="space-y-4 text-sm">
              <div>
                <span className="text-xs font-semibold text-[#C49A43] uppercase tracking-wide block mb-1">
                  Culinary Description:
                </span>
                <p className="text-[#F3E7C9] leading-relaxed">
                  {activeDish.description}
                </p>
              </div>

              <div className="bg-[#183D2B]/80 p-3.5 rounded-xl border border-white/10">
                <span className="text-xs font-semibold text-[#C49A43] uppercase tracking-wide block mb-1">
                  Traditional Serving Wisdom:
                </span>
                <p className="text-xs text-[#F3E7C9]/90 leading-relaxed">
                  {activeDish.servingOrder}
                </p>
              </div>
            </div>

            <div className="pt-2">
              <Link
                href="/book?serving=arati_aaku"
                className="w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-[#C49A43] to-[#A37B2E] text-[#183D2B] font-bold text-base shadow-xl hover:shadow-2xl hover:scale-[1.02] transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-[#183D2B]" />
                <span>Choose Your Banana Leaf Feast</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>

        {/* Serving Style Options Configurator Notice */}
        <div className="bg-[#122D20]/90 border border-[#C49A43]/40 rounded-3xl p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-4 text-[#C49A43]">
            <Info className="w-5 h-5 shrink-0" />
            <h4 className="font-serif-brand text-lg font-bold text-[#FFF9EA]">
              Configurable Serving Styles For Your Event
            </h4>
          </div>
          <p className="text-xs sm:text-sm text-[#F3E7C9]/85 mb-6 leading-relaxed">
            Sri Chakra Caterers provides complete flexibility for your venue setup. Banana-leaf serving is not automatically enforced on every package—you select your preferred style during booking:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            {/* Style 1 */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border-2 border-[#C49A43] shadow-md">
              <div className="flex items-center gap-2 text-[#C49A43] font-bold mb-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>1. Traditional Arati Aaku</span>
              </div>
              <p className="text-xs text-[#F3E7C9]/80 leading-relaxed">
                Fresh green banana leaf dining with traditional seated dining or standing leaf arrangement. Extra leaf setup cost is owner-verified upon booking.
              </p>
            </div>

            {/* Style 2 */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border border-white/10">
              <div className="flex items-center gap-2 text-[#F3E7C9] font-bold mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#C49A43]" />
                <span>2. Regular Plates Buffet</span>
              </div>
              <p className="text-xs text-[#F3E7C9]/80 leading-relaxed">
                Premium high-grade melamime or disposable plates with cups, spoons, and warm chafing dishes included in all standard packages.
              </p>
            </div>

            {/* Style 3 */}
            <div className="p-4 rounded-2xl bg-[#183D2B] border border-white/10">
              <div className="flex items-center gap-2 text-[#F3E7C9] font-bold mb-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#C49A43]" />
                <span>3. Custom Arrangement</span>
              </div>
              <p className="text-xs text-[#F3E7C9]/80 leading-relaxed">
                Combined leaf & plate service, live counters, steel thali service, or custom wedding arrangements verified directly with the owner.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
