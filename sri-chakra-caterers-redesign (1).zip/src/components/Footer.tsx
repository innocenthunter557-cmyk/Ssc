"use client";

import React from "react";
import Link from "next/link";
import { Phone, MessageCircle, MapPin, Clock, ShieldCheck, Heart } from "lucide-react";

interface FooterProps {
  primaryPhone?: string;
  whatsappNumber?: string;
  instagram?: string;
  primaryLocation?: string;
}

export default function Footer({
  primaryPhone = "9705075113",
  whatsappNumber = "9705075113",
  instagram = "@srichakracaterers_",
  primaryLocation = "Kothapet and Meerpet, Hyderabad, Telangana",
}: FooterProps) {
  return (
    <footer className="bg-[#122D20] text-[#FFF9EA] border-t-2 border-[#C49A43]/40 relative overflow-hidden">
      {/* Decorative Gold Border Line */}
      <div className="h-1 bg-gradient-to-r from-transparent via-[#C49A43] to-transparent opacity-80" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#C49A43] to-[#8C6826] flex items-center justify-center text-[#183D2B] font-bold text-xl border-2 border-[#FFF9EA]/50 shadow-md">
                SC
              </div>
              <div>
                <span className="font-serif-brand text-2xl font-bold tracking-tight text-[#FFF9EA] block leading-none">
                  Sri Chakra Caterers
                </span>
                <span className="text-xs text-[#C49A43] font-medium tracking-wider uppercase block mt-1">
                  Hyderabad
                </span>
              </div>
            </div>

            <p className="text-sm text-[#F3E7C9]/90 italic font-serif leading-relaxed">
              &ldquo;Deliciously Crafted. Perfectly Served.&rdquo;
            </p>
            <p className="text-xs text-[#C49A43] font-medium leading-relaxed">
              Good Food. Happy People. Blessed Occasions.
            </p>

            <div className="pt-2 text-xs text-[#F3E7C9]/80 space-y-1.5">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#C49A43] shrink-0 mt-0.5" />
                <span>{primaryLocation}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#C49A43] shrink-0" />
                <span>Bookings: 7:00 AM – 10:00 PM (Daily)</span>
              </div>
            </div>
          </div>

          {/* Quick Menus Column */}
          <div>
            <h4 className="font-serif-brand text-lg font-bold text-[#C49A43] mb-4 border-b border-[#C49A43]/30 pb-2">
              Signature Menus
            </h4>
            <ul className="space-y-2 text-sm text-[#F3E7C9]/85">
              <li>
                <Link href="/menu/veg_grand_399" className="hover:text-[#C49A43] transition-colors flex items-center justify-between">
                  <span>Veg Grand Menu (Custom)</span>
                  <span className="text-xs font-bold text-[#C49A43]">₹399/plate</span>
                </Link>
              </li>
              <li>
                <Link href="/menu/home_delivery_25" className="hover:text-[#C49A43] transition-colors flex items-center justify-between">
                  <span>Home-Delivery Feast (25 Mem)</span>
                  <span className="text-xs font-bold text-[#C49A43]">₹4,500</span>
                </Link>
              </li>
              <li>
                <Link href="/menu/veg_special_280" className="hover:text-[#C49A43] transition-colors flex items-center justify-between">
                  <span>Pure Veg Special (20 Items)</span>
                  <span className="text-xs font-bold text-[#C49A43]">₹280/plate</span>
                </Link>
              </li>
              <li>
                <Link href="/menu/nonveg_standard_399" className="hover:text-[#C49A43] transition-colors flex items-center justify-between">
                  <span>Non-Veg Mutton Biryani</span>
                  <span className="text-xs font-bold text-[#C49A43]">₹399/plate</span>
                </Link>
              </li>
              <li>
                <Link href="/menu/nonveg_silver_479" className="hover:text-[#C49A43] transition-colors flex items-center justify-between">
                  <span>Non-Veg Silver Luxury</span>
                  <span className="text-xs font-bold text-[#C49A43]">₹479/plate</span>
                </Link>
              </li>
              <li>
                <Link href="/menu/veg_basic2_200" className="hover:text-[#C49A43] transition-colors flex items-center justify-between">
                  <span>Traditional Basic Menu</span>
                  <span className="text-xs font-bold text-[#C49A43]">₹200/plate</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick Links & Service Areas */}
          <div>
            <h4 className="font-serif-brand text-lg font-bold text-[#C49A43] mb-4 border-b border-[#C49A43]/30 pb-2">
              Catering Services
            </h4>
            <ul className="space-y-2 text-sm text-[#F3E7C9]/85">
              <li>
                <Link href="/#arati-aaku" className="hover:text-[#C49A43] transition-colors">
                  Traditional Arati Aaku (అరిటాకు)
                </Link>
              </li>
              <li>
                <Link href="/book" className="hover:text-[#C49A43] transition-colors">
                  Multi-Step Booking Wizard
                </Link>
              </li>
              <li>
                <Link href="/track" className="hover:text-[#C49A43] transition-colors">
                  Track Your Booking Enquiry
                </Link>
              </li>
              <li>
                <span className="text-xs text-[#C49A43] font-semibold block uppercase tracking-wider mt-3 mb-1">
                  Service Hubs:
                </span>
                <span className="text-xs text-[#F3E7C9]/70 leading-relaxed block">
                  Kothapet, Meerpet, LB Nagar, Dilsukhnagar, Saroornagar, Karmanghat, Uppal, Gachibowli, Kukatpally & all Hyderabad regions.
                </span>
              </li>
            </ul>
          </div>

          {/* Verified Contact & Connect */}
          <div>
            <h4 className="font-serif-brand text-lg font-bold text-[#C49A43] mb-4 border-b border-[#C49A43]/30 pb-2">
              Connect With Us
            </h4>
            <div className="space-y-3 text-sm">
              <a
                href={`tel:+91${primaryPhone}`}
                className="flex items-center gap-2.5 p-2.5 rounded-lg bg-[#183D2B] border border-[#C49A43]/30 hover:border-[#C49A43] transition-all text-[#FFF9EA]"
              >
                <Phone className="w-4 h-4 text-[#C49A43]" />
                <div>
                  <span className="text-[11px] text-[#C49A43] uppercase block font-semibold">Call For Catering</span>
                  <span className="font-bold text-base">+91 {primaryPhone}</span>
                </div>
              </a>

              <a
                href={`https://wa.me/91${whatsappNumber}?text=Hello%20Sri%20Chakra%20Caterers,%20I%20would%20like%20to%20enquire%20about%20catering%20services.`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 p-2.5 rounded-lg bg-[#25D366]/20 border border-[#25D366]/40 hover:bg-[#25D366]/30 transition-all text-[#FFF9EA]"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <div>
                  <span className="text-[11px] text-[#25D366] uppercase block font-semibold">WhatsApp Chat</span>
                  <span className="font-bold text-base">+91 {whatsappNumber}</span>
                </div>
              </a>

              <a
                href={`https://instagram.com/${instagram.replace("@", "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#F3E7C9]/85 hover:text-[#C49A43] pt-1"
              >
                <svg className="w-4 h-4 text-[#C49A43] fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
                <span>Instagram: <span className="font-semibold text-[#FFF9EA]">{instagram}</span></span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar with copyright and admin link */}
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#F3E7C9]/60">
          <p>© {new Date().getFullYear()} Sri Chakra Caterers. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <Link href="/admin/login" className="hover:text-[#C49A43] transition-colors flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Owner / Admin Portal</span>
            </Link>
            <span>•</span>
            <span className="flex items-center gap-1">
              Crafted with <Heart className="w-3 h-3 text-[#C49A43] inline fill-[#C49A43]" /> for Blessed Occasions
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
