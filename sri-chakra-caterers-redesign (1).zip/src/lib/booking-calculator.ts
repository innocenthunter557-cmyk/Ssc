import type { CateringPackage, ServingStyle } from "./types";

export interface CalculationResult {
  packagePrice: number;
  pricingType: "per_plate" | "fixed_package";
  guestCount: number;
  foodCost: number;
  servingStyleCost: number;
  totalEstimatedAmount: number;
  isPricePendingConfirmation: boolean;
  pricePendingReason: string | null;
  ruleNotes: string[];
}

export function calculateBookingCost(
  pkg: CateringPackage,
  guestCount: number,
  servingStyle: ServingStyle,
  leafExtraPricePerPlate: number | null = null
): CalculationResult {
  const priceNum = parseFloat(pkg.price);
  const ruleNotes: string[] = [];
  let isPricePendingConfirmation = false;
  let pricePendingReason: string | null = null;
  let foodCost = 0;
  let servingStyleCost = 0;

  if (pkg.pricingType === "fixed_package") {
    // Fixed package e.g. ₹4,500 for 25 members
    const baseMembers = pkg.fixedMemberCount || 25;
    foodCost = priceNum;

    if (guestCount !== baseMembers) {
      isPricePendingConfirmation = true;
      pricePendingReason = `This package is fixed at ₹${priceNum.toLocaleString("en-IN")} for exactly ${baseMembers} members. For ${guestCount} members, an owner-confirmed custom quotation is required.`;
      ruleNotes.push(`Fixed package of ₹${priceNum.toLocaleString("en-IN")} for ${baseMembers} members selected.`);
      ruleNotes.push(`Guest count is ${guestCount} (different from ${baseMembers}). Custom quotation requested.`);
    } else {
      ruleNotes.push(`Fixed package: ₹${priceNum.toLocaleString("en-IN")} for ${baseMembers} members.`);
    }
  } else {
    // Per plate package e.g. ₹200, ₹220, ₹260, ₹280, ₹299, ₹399, ₹479
    foodCost = priceNum * guestCount;
    ruleNotes.push(`₹${priceNum.toLocaleString("en-IN")} × ${guestCount} plates = ₹${foodCost.toLocaleString("en-IN")}`);
  }

  // Serving style cost
  if (servingStyle === "arati_aaku") {
    if (leafExtraPricePerPlate !== null && leafExtraPricePerPlate > 0) {
      servingStyleCost = leafExtraPricePerPlate * guestCount;
      ruleNotes.push(`Arati Aaku (Fresh Banana Leaf) serving: ₹${leafExtraPricePerPlate} × ${guestCount} = ₹${servingStyleCost.toLocaleString("en-IN")}`);
    } else {
      servingStyleCost = 0;
      ruleNotes.push("Arati Aaku (Fresh Banana Leaf) serving selected. Extra leaf setup cost is subject to owner confirmation.");
    }
  } else if (servingStyle === "custom") {
    isPricePendingConfirmation = true;
    pricePendingReason = (pricePendingReason ? pricePendingReason + " " : "") + "Custom serving arrangement requested. Final quote to be verified by owner.";
    ruleNotes.push("Custom serving arrangement requested. Final price to be confirmed.");
  }

  const totalEstimatedAmount = foodCost + servingStyleCost;

  return {
    packagePrice: priceNum,
    pricingType: pkg.pricingType,
    guestCount,
    foodCost,
    servingStyleCost,
    totalEstimatedAmount,
    isPricePendingConfirmation,
    pricePendingReason,
    ruleNotes,
  };
}
