import React from "react";
import type { Metadata } from "next";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getAllPackages, getSiteSettings, getAllBookings } from "@/lib/data";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { desc } from "drizzle-orm";
import AdminDashboardClient from "./AdminDashboardClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Admin Dashboard | Sri Chakra Caterers",
  description: "Management and order control dashboard for Sri Chakra Caterers.",
};

export default async function AdminPage() {
  const cookieStore = await cookies();
  const session = cookieStore.get("scc_admin_session")?.value;

  if (!session) {
    redirect("/admin/login");
  }

  // Fetch all admin data
  const [settings, packages, bookingsList] = await Promise.all([
    getSiteSettings(),
    getAllPackages(),
    getAllBookings(),
  ]);

  const logs = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(20);

  return (
    <main>
      <AdminDashboardClient
        initialSettings={settings}
        initialPackages={packages}
        initialBookings={bookingsList}
        auditLogsList={logs}
      />
    </main>
  );
}
