import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adminUsers, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  try {
    const { username, password } = await req.json();

    if (!username || !password) {
      return NextResponse.json({ success: false, error: "Username and password required." }, { status: 400 });
    }

    const inputHash = crypto.createHash("sha256").update(password).digest("hex");

    const users = await db.select().from(adminUsers).where(eq(adminUsers.username, username.trim())).limit(1);

    if (users.length === 0 || users[0].passwordHash !== inputHash) {
      return NextResponse.json({ success: false, error: "Invalid admin credentials." }, { status: 401 });
    }

    const user = users[0];

    // Create session token
    const sessionToken = Buffer.from(JSON.stringify({ id: user.id, username: user.username, role: user.role, time: Date.now() })).toString("base64");

    // Log login
    await db.insert(auditLogs).values({
      actor: user.username,
      action: "admin_login",
      entityType: "admin_user",
      entityId: String(user.id),
      details: { role: user.role },
    });

    const res = NextResponse.json({
      success: true,
      user: { id: user.id, username: user.username, fullName: user.fullName, role: user.role },
    });

    res.cookies.set("scc_admin_session", sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24, // 24 hours
    });

    return res;
  } catch (error) {
    return NextResponse.json({ success: false, error: "Authentication failed." }, { status: 500 });
  }
}

export async function DELETE() {
  const res = NextResponse.json({ success: true, message: "Logged out" });
  res.cookies.delete("scc_admin_session");
  return res;
}

export async function GET(req: NextRequest) {
  const session = req.cookies.get("scc_admin_session")?.value;
  if (!session) {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }
  try {
    const payload = JSON.parse(Buffer.from(session, "base64").toString("utf-8"));
    return NextResponse.json({ authenticated: true, user: payload });
  } catch {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }
}
