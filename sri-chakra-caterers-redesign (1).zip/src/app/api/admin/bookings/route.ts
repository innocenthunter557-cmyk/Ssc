import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { bookings, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest) {
  try {
    const { id, status, adminNotes } = await req.json();

    if (!id) {
      return NextResponse.json({ success: false, error: "Booking ID required." }, { status: 400 });
    }

    const [updated] = await db
      .update(bookings)
      .set({
        status: status || undefined,
        adminNotes: adminNotes !== undefined ? adminNotes : undefined,
        updatedAt: new Date(),
      })
      .where(eq(bookings.id, id))
      .returning();

    await db.insert(auditLogs).values({
      actor: "admin",
      action: "booking_status_updated",
      entityType: "booking",
      entityId: String(id),
      details: { newStatus: status, notes: adminNotes },
    });

    return NextResponse.json({ success: true, booking: updated });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to update booking." }, { status: 500 });
  }
}
