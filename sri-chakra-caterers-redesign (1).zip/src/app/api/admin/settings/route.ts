import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { siteSettings, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      primaryPhone,
      whatsappNumber,
      alternatePhone,
      phoneConflictFlagged,
      phoneConflictNote,
      bananaLeafExtraPricePerPlate,
      homeDeliveryAdvanceDays,
      serviceAreas,
    } = body;

    const [updated] = await db
      .update(siteSettings)
      .set({
        primaryPhone: primaryPhone || undefined,
        whatsappNumber: whatsappNumber || undefined,
        alternatePhone: alternatePhone !== undefined ? alternatePhone : undefined,
        phoneConflictFlagged: phoneConflictFlagged !== undefined ? phoneConflictFlagged : undefined,
        phoneConflictNote: phoneConflictNote !== undefined ? phoneConflictNote : undefined,
        bananaLeafExtraPricePerPlate: bananaLeafExtraPricePerPlate !== undefined ? (bananaLeafExtraPricePerPlate ? String(bananaLeafExtraPricePerPlate) : null) : undefined,
        homeDeliveryAdvanceDays: homeDeliveryAdvanceDays !== undefined ? Number(homeDeliveryAdvanceDays) : undefined,
        serviceAreas: serviceAreas !== undefined ? serviceAreas : undefined,
        updatedAt: new Date(),
      })
      .where(eq(siteSettings.id, 1))
      .returning();

    await db.insert(auditLogs).values({
      actor: "admin",
      action: "settings_updated",
      entityType: "site_settings",
      entityId: "1",
      details: { primaryPhone, whatsappNumber, phoneConflictFlagged },
    });

    return NextResponse.json({ success: true, settings: updated });
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to update settings." }, { status: 500 });
  }
}
