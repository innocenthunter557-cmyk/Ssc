import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { getSiteSettings } from "@/lib/data";
import { LanguageProvider } from "@/lib/language-context";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Sri Chakra Caterers | Deliciously Crafted. Perfectly Served.",
  description: "Sri Chakra Caterers in Kothapet and Meerpet, Hyderabad. Traditional Arati Aaku banana-leaf serving, pure vegetarian grand menus, and authentic Hyderabadi Dum Biryani catering.",
  keywords: [
    "Sri Chakra Caterers",
    "Arati Aaku catering Hyderabad",
    "South Indian wedding catering",
    "Banana leaf feast Hyderabad",
    "Pure vegetarian catering Kothapet Meerpet",
    "Hyderabadi Dum Biryani catering",
  ],
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const settings = await getSiteSettings();

  return (
    <html lang="en">
      <body className="bg-[#FFF9EA] text-[#183D2B] antialiased min-h-screen flex flex-col font-sans">
        <LanguageProvider>
          <Navbar
            primaryPhone={settings.primaryPhone}
            whatsappNumber={settings.whatsappNumber}
          />
          <div className="flex-1">{children}</div>
          <Footer
            primaryPhone={settings.primaryPhone}
            whatsappNumber={settings.whatsappNumber}
            instagram={settings.instagram}
            primaryLocation={settings.primaryLocation}
          />
        </LanguageProvider>
      </body>
    </html>
  );
}
