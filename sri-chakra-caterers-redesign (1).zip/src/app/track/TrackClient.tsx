"use client";

import React, { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Search, Clock, CheckCircle2, MessageCircle, AlertCircle, Phone } from "lucide-react";

export default function TrackClient() {
  const searchParams = useSearchParams();
  const initialRef = searchParams.get("ref") || "";

  const [refInput, setRefInput] = useState<string>(initialRef);
  const [loading, setLoading] = useState<boolean>(false);
  const [booking, setBooking] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchBooking = async (ref: string) => {
    if (!ref.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/bookings/track?ref=${encodeURIComponent(ref.trim())}`);
      const data = await res.json();
      if (!res.ok || !data.success) {
        setError(data.error || "Enquiry reference not found.");
        setBooking(null);
      } else {
        setBooking(data.booking);
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialRef) {
      fetchBooking(initialRef);
    }
  }, [initialRef]);

  return (
    <div className="max-w-2xl mx-auto py-12 sm:py-16 px-4 sm:px-6">
      <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <span className="text-xs uppercase font-bold text-[#557A3B] tracking-wider">
            Real-Time Enquiry Tracking
          </span>
          <h1 className="font-serif-brand text-2xl sm:text-3xl font-bold text-[#183D2B]">
            Track Your Catering Enquiry
          </h1>
          <p className="text-xs sm:text-sm text-slate-600">
            Enter your unique enquiry reference (e.g. SCC-2026-XXXX)
          </p>
        </div>

        {/* Search input form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchBooking(refInput);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            placeholder="SCC-2026-XXXX"
            value={refInput}
            onChange={(e) => setRefInput(e.target.value)}
            className="flex-1 p-3 rounded-2xl bg-[#FFF9EA] border-2 border-[#C49A43] font-mono font-bold text-center text-sm uppercase focus:outline-none focus:ring-2 focus:ring-[#183D2B]"
          />
          <button
            type="submit"
            disabled={loading || !refInput.trim()}
            className="px-6 py-3 rounded-2xl bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-all disabled:opacity-50"
          >
            <Search className="w-4 h-4" />
            <span>{loading ? "Searching..." : "Track"}</span>
          </button>
        </form>

        {error && (
          <div className="p-3.5 rounded-2xl bg-red-50 text-red-800 border border-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Enquiry Result Details */}
        {booking && (
          <div className="mt-6 p-6 rounded-2xl bg-[#FFF9EA] border-2 border-[#C49A43]/60 space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-[#C49A43]/30 pb-3">
              <div>
                <span className="text-[11px] font-mono font-bold text-[#68462D] block">
                  Reference: {booking.referenceNumber}
                </span>
                <h2 className="font-serif-brand text-xl font-bold text-[#183D2B] mt-0.5">
                  {booking.packageName}
                </h2>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-[#183D2B] text-[#C49A43]">
                {booking.status.replace("_", " ")}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-500 block">Customer:</span>
                <span className="font-bold text-[#183D2B]">{booking.customerName}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Phone:</span>
                <span className="font-bold text-[#183D2B]">{booking.customerPhone}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Event Date:</span>
                <span className="font-bold text-[#183D2B]">{booking.eventDate} ({booking.servingTime})</span>
              </div>
              <div>
                <span className="text-slate-500 block">Guests:</span>
                <span className="font-bold text-[#183D2B]">{booking.guestCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Serving Style:</span>
                <span className="font-bold text-[#183D2B] capitalize">{booking.servingStyle.replace("_", " ")}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Estimated Amount:</span>
                <span className="font-bold text-[#183D2B] text-sm">
                  ₹{parseFloat(booking.totalEstimatedAmount).toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-[#C49A43]/20 flex justify-between items-center gap-2">
              <span className="text-[11px] text-slate-500">
                Need urgent assistance?
              </span>
              <a
                href={`https://wa.me/919705075113?text=Hi%20Sri%20Chakra%20Caterers,%20I%20am%20following%20up%20on%20my%20enquiry%20reference:%20${booking.referenceNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-full bg-[#25D366] text-white text-xs font-bold flex items-center gap-1.5 shadow"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp Owner</span>
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
