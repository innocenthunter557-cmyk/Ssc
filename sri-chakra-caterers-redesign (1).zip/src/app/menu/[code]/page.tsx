import React from "react";
import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { getPackageByCode } from "@/lib/data";
import { Sparkles, Utensils, CheckCircle2, ChevronLeft, ShieldCheck, Phone, ArrowRight } from "lucide-react";

export const dynamic = "force-dynamic";

interface PackagePageProps {
  params: Promise<{ code: string }>;
}

export async function generateMetadata({ params }: PackagePageProps): Promise<Metadata> {
  const { code } = await params;
  const pkg = await getPackageByCode(code);
  if (!pkg) {
    return { title: "Package Not Found | Sri Chakra Caterers" };
  }
  return {
    title: `${pkg.titleEn} | Sri Chakra Caterers Hyderabad`,
    description: pkg.description,
  };
}

export default async function PackageDetailPage({ params }: PackagePageProps) {
  const { code } = await params;
  const pkg = await getPackageByCode(code);

  if (!pkg) {
    notFound();
  }

  const isVeg = pkg.dietType === "veg";
  const isFixed = pkg.pricingType === "fixed_package";
  const priceNum = parseFloat(pkg.price);

  return (
    <main className="min-h-screen bg-[#FFF9EA] py-10 sm:py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Back Link */}
        <Link
          href="/menu"
          className="inline-flex items-center gap-1.5 text-xs font-bold text-[#557A3B] hover:text-[#183D2B] transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to All Catering Menus</span>
        </Link>

        {/* Hero Package Banner */}
        <div className="bg-[#183D2B] text-[#FFF9EA] rounded-3xl overflow-hidden border-2 border-[#C49A43] shadow-2xl relative">
          <div className="relative h-64 sm:h-80 w-full">
            <Image
              src={pkg.imageUrl || "/images/arati-aaku-feast.jpg"}
              alt={pkg.titleEn}
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#183D2B] via-[#183D2B]/60 to-transparent" />
          </div>

          <div className="p-6 sm:p-10 relative -mt-20 z-10 space-y-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className={`px-3 py-1 rounded-full text-xs font-bold ${
                  isVeg ? "bg-[#25482F] text-[#FFF9EA]" : "bg-[#762B20] text-[#FFF9EA]"
                }`}
              >
                {isVeg ? "Pure Vegetarian" : "Non-Vegetarian"}
              </span>
              {pkg.badge && (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#C49A43] text-[#183D2B]">
                  {pkg.badge}
                </span>
              )}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <h1 className="font-serif-brand text-3xl sm:text-5xl font-bold text-[#FFF9EA]">
                  {pkg.titleEn}
                </h1>
                {pkg.titleTe && (
                  <p className="text-lg text-[#C49A43] font-serif mt-1">
                    {pkg.titleTe}
                  </p>
                )}
              </div>

              <div className="text-left sm:text-right bg-[#122D20]/80 p-4 rounded-2xl border border-[#C49A43]/40">
                <span className="text-3xl sm:text-4xl font-bold font-serif-brand text-[#C49A43]">
                  ₹{priceNum.toLocaleString("en-IN")}
                </span>
                <span className="text-xs text-[#F3E7C9]/80 block mt-0.5">
                  {isFixed ? `Fixed for ${pkg.fixedMemberCount || 25} members` : "per plate"}
                </span>
              </div>
            </div>

            <p className="text-sm sm:text-base text-[#F3E7C9]/90 max-w-3xl leading-relaxed pt-2">
              {pkg.description}
            </p>

            {/* Poster notes flag */}
            {pkg.posterNotes && (
              <div className="p-3.5 rounded-xl bg-[#122D20] border border-[#C49A43]/40 text-xs text-[#F3E7C9] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#C49A43] shrink-0" />
                <span>Original Poster Note: {pkg.posterNotes}</span>
              </div>
            )}
          </div>
        </div>

        {/* Content Columns: Dishes and Inclusions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Dishes List (2 Cols) */}
          <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-center justify-between border-b pb-4">
              <div>
                <h2 className="font-serif-brand text-2xl font-bold text-[#183D2B]">
                  Menu Courses & Items ({pkg.items?.length || 0})
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  {pkg.isCustomizable
                    ? "Custom category selection package"
                    : "Fixed traditional Telugu course lineup"}
                </p>
              </div>
              <Utensils className="w-6 h-6 text-[#557A3B]" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              {(pkg.items || []).map((item, idx) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-[#FFF9EA] border border-[#C49A43]/30 flex items-center justify-between gap-2"
                >
                  <div>
                    <span className="font-bold text-[#183D2B] block">
                      {idx + 1}. {item.itemNameEn}
                    </span>
                    {item.itemNameTe && (
                      <span className="text-xs text-[#68462D] font-serif block">
                        {item.itemNameTe}
                      </span>
                    )}
                  </div>
                  {item.categoryGroup && (
                    <span className="text-[10px] uppercase font-bold text-slate-500 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                      {item.categoryGroup}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Inclusions & Booking CTA (1 Col) */}
          <div className="space-y-6">
            {/* Inclusions Box */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
              <h3 className="font-serif-brand text-xl font-bold text-[#183D2B]">
                Included Services
              </h3>
              <div className="space-y-2 text-xs">
                {(pkg.includedServices || []).map((svc, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{svc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct Booking CTA */}
            <div className="bg-[#183D2B] text-[#FFF9EA] rounded-3xl p-6 border-2 border-[#C49A43] shadow-lg space-y-4">
              <span className="text-xs uppercase font-bold text-[#C49A43] tracking-widest block">
                Ready To Book?
              </span>
              <h4 className="font-serif-brand text-xl font-bold text-[#FFF9EA]">
                Reserve {pkg.titleEn}
              </h4>
              <p className="text-xs text-[#F3E7C9]/80 leading-relaxed">
                Open our multi-step booking wizard to select your guest count, serving style, and event details.
              </p>

              <Link
                href={`/book?pkg=${pkg.id}`}
                className="w-full py-3.5 px-4 rounded-full bg-gradient-to-r from-[#C49A43] to-[#A37B2E] text-[#183D2B] font-bold text-sm flex items-center justify-center gap-2 shadow-md hover:scale-105 transition-all"
              >
                <Sparkles className="w-4 h-4 text-[#183D2B]" />
                <span>{pkg.isCustomizable ? "Customise & Book" : "Book This Menu"}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
