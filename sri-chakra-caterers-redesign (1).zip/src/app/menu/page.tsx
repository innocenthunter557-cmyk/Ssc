import React from "react";
import type { Metadata } from "next";
import { getAllPackages } from "@/lib/data";
import MenuPageClient from "./MenuPageClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Catering Menus & Packages | Sri Chakra Caterers Hyderabad",
  description: "Browse our 8 traditional South Indian catering packages. Pure vegetarian menus from ₹200 to ₹399, Hyderabadi non-vegetarian menus from ₹299 to ₹479, and home delivery feast ₹4,500 for 25 members.",
};

export default async function MenuPage() {
  const packages = await getAllPackages();

  return (
    <main className="min-h-screen bg-[#FFF9EA]">
      <MenuPageClient packages={packages} />
    </main>
  );
}
