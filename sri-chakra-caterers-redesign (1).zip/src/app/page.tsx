import React from "react";
import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import {
  Sparkles,
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  ShieldCheck,
  CheckCircle2,
  UtensilsCrossed,
  ArrowRight,
  Heart,
  Calendar,
  ChefHat,
  Award,
} from "lucide-react";
import { getAllPackages, getSiteSettings } from "@/lib/data";
import HeroSlider from "@/components/HeroSlider";
import ScrollingRibbon from "@/components/ScrollingRibbon";
import AratiAakuSection from "@/components/AratiAakuSection";
import PackageCard from "@/components/PackageCard";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Sri Chakra Caterers | Deliciously Crafted. Perfectly Served.",
  description: "Official website of Sri Chakra Caterers in Kothapet and Meerpet, Hyderabad. Traditional Arati Aaku banana-leaf feasts, pure vegetarian catering, and authentic Hyderabadi Dum Biryani banquets.",
};

export default async function HomePage() {
  const [packages, settings] = await Promise.all([
    getAllPackages(),
    getSiteSettings(),
  ]);

  // Featured Packages
  const vegGrand = packages.find((p) => p.code === "veg_grand_399") || packages[0];
  const homeDelivery = packages.find((p) => p.code === "home_delivery_25");
  const vegSpecial = packages.find((p) => p.code === "veg_special_280");
  const nonvegStandard = packages.find((p) => p.code === "nonveg_standard_399");
  const nonvegSilver = packages.find((p) => p.code === "nonveg_silver_479");

  return (
    <main className="min-h-screen bg-[#FFF9EA] text-[#183D2B] overflow-x-hidden">
      {/* 1. Cinematic Hero Slider */}
      <HeroSlider />

      {/* 2. Scrolling Announcement Ribbon */}
      <ScrollingRibbon />

      {/* 3. The Tradition of Arati Aaku Signature Section */}
      <AratiAakuSection />

      {/* 4. Explore Our Menus Overview */}
      <section className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-[#557A3B]">
              Handcrafted Culinary Packages
            </span>
            <h2 className="font-serif-brand text-3xl sm:text-5xl font-bold text-[#183D2B]">
              Explore Our Signature Menus
            </h2>
            <p className="text-xs sm:text-sm text-slate-700 max-w-xl">
              From pure vegetarian traditional feasts to celebratory Hyderabadi mutton dum biryani banquets.
            </p>
          </div>

          <Link
            href="/menu"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-[#183D2B] hover:text-[#557A3B] transition-colors group"
          >
            <span>View All 8 Menu Packages</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {/* Featured Package Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.slice(0, 6).map((pkg) => (
            <PackageCard key={pkg.id} pkg={pkg} />
          ))}
        </div>
      </section>

      {/* 5. Special Home-Delivery Feature Banner (₹4,500 for 25 Members) */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 bg-[#183D2B] text-[#FFF9EA] relative overflow-hidden">
        <div className="absolute inset-0 kolam-pattern opacity-10 pointer-events-none" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C49A43]/20 border border-[#C49A43] text-xs font-bold text-[#C49A43] uppercase tracking-wider">
              <span>Home Delivery Special</span>
              <span>•</span>
              <span>Hyderabad</span>
            </div>

            <h2 className="font-serif-brand text-3xl sm:text-4xl lg:text-5xl font-bold text-[#FFF9EA]">
              Special Home-Delivery Feast — ₹4,500 for 25 Members
            </h2>

            <p className="text-sm sm:text-base text-[#F3E7C9]/90 leading-relaxed max-w-2xl">
              Planning an auspicious pooja, family get-together, or house celebration? Our fixed home-delivery package brings 10 complete traditional Telugu courses packed fresh in hygienic food carriers straight to your doorstep across Hyderabad.
            </p>

            {/* Menu List Badges */}
            <div className="flex flex-wrap gap-2 pt-2 text-xs">
              {[
                "1. Steaming Rice",
                "2. Pappu",
                "3. Sambar",
                "4. Curry",
                "5. Hot/Karam",
                "6. Sweet",
                "7. Pickle",
                "8. Papad",
                "9. Curd",
                "10. Ghee",
              ].map((item, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded-xl bg-[#122D20] text-[#F3E7C9] border border-white/10 font-medium"
                >
                  {item}
                </span>
              ))}
            </div>

            <div className="pt-4 flex items-center gap-4 flex-wrap">
              <Link
                href="/menu/home_delivery_25"
                className="px-6 py-3.5 rounded-full bg-[#C49A43] text-[#183D2B] font-bold text-sm shadow-xl hover:scale-105 transition-all flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-[#183D2B]" />
                <span>Order Home Delivery (₹4,500)</span>
              </Link>

              <span className="text-xs text-[#F3E7C9]/80">
                * Order 2–3 days in advance • Delivery across Hyderabad
              </span>
            </div>
          </div>

          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden border-2 border-[#C49A43] shadow-2xl">
              <Image
                src="/images/home-delivery-feast.jpg"
                alt="Sri Chakra Caterers Special Home Delivery Feast ₹4,500"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 6. Wedding & Auspicious Occasion Catering */}
      <section className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-[#122D20] text-[#FFF9EA] rounded-3xl p-8 sm:p-12 lg:p-16 border-2 border-[#C49A43] shadow-2xl relative overflow-hidden">
          <div className="absolute right-0 bottom-0 w-1/2 h-full opacity-15 pointer-events-none">
            <Image
              src="/images/wedding-catering-setup.jpg"
              alt="Wedding catering background"
              fill
              className="object-cover"
            />
          </div>

          <div className="max-w-2xl space-y-6 relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#557A3B]/30 border border-[#C49A43]/40 text-xs font-semibold text-[#F3E7C9] uppercase">
              <span>Weddings • Engagements • Gruhapravesam</span>
            </div>

            <h2 className="font-serif-brand text-3xl sm:text-5xl font-bold text-[#FFF9EA]">
              Blessed Occasions Deserve Sacred Hospitality
            </h2>

            <p className="text-sm sm:text-base text-[#F3E7C9]/90 leading-relaxed font-sans">
              Sri Chakra Caterers brings decades of traditional culinary mastery, experienced serving staff, and authentic Telugu recipes cooked with Vijaya Ghee and Gold Drop Oil. Whether serving 100 or 1,000 guests, every guest is treated with reverence and warmth.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-2 text-xs">
              <div className="p-3.5 rounded-2xl bg-[#183D2B] border border-white/10 space-y-1">
                <span className="font-bold text-[#C49A43] block">Traditional Seating</span>
                <span className="text-[#F3E7C9]/80">Pankthi Bhojanam on fresh banana leaves</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-[#183D2B] border border-white/10 space-y-1">
                <span className="font-bold text-[#C49A43] block">Live Counters</span>
                <span className="text-[#F3E7C9]/80">Tawa rotis, jalebi, bajjis & welcome drinks</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-[#183D2B] border border-white/10 space-y-1">
                <span className="font-bold text-[#C49A43] block">Royal Service</span>
                <span className="text-[#F3E7C9]/80">Uniformed staff & ornate brass vessels</span>
              </div>
            </div>

            <div className="pt-4 flex items-center gap-4 flex-wrap">
              <Link
                href="/book"
                className="px-8 py-3.5 rounded-full bg-gradient-to-r from-[#C49A43] to-[#A37B2E] text-[#183D2B] font-bold text-sm sm:text-base shadow-xl hover:scale-105 transition-all flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-[#183D2B]" />
                <span>Start Catering Booking Wizard</span>
              </Link>

              <a
                href={`tel:+91${settings.primaryPhone}`}
                className="px-6 py-3.5 rounded-full bg-white/10 hover:bg-white/20 text-[#FFF9EA] font-semibold text-sm border border-white/20 transition-all flex items-center gap-2"
              >
                <Phone className="w-4 h-4 text-[#C49A43]" />
                <span>Call +91 {settings.primaryPhone}</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Locations & Direct Contacts */}
      <section className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-xl grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2">
            <span className="text-xs uppercase font-bold text-[#557A3B] tracking-wider block">
              Direct Contact
            </span>
            <h3 className="font-serif-brand text-2xl font-bold text-[#183D2B]">
              Ready to Discuss Your Date?
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              We cater across all areas of Hyderabad & Secunderabad from our twin hubs in Kothapet and Meerpet.
            </p>
          </div>

          <div className="space-y-3 text-xs sm:text-sm">
            <div className="flex items-center gap-3 text-slate-800">
              <MapPin className="w-5 h-5 text-[#557A3B] shrink-0" />
              <span>Kothapet & Meerpet, Hyderabad, Telangana</span>
            </div>
            <div className="flex items-center gap-3 text-slate-800">
              <Phone className="w-5 h-5 text-[#C49A43] shrink-0" />
              <span className="font-bold">+91 {settings.primaryPhone}</span>
            </div>
            <div className="flex items-center gap-3 text-slate-800">
              <MessageCircle className="w-5 h-5 text-[#25D366] shrink-0" />
              <span>WhatsApp: +91 {settings.whatsappNumber}</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row md:flex-col gap-3">
            <Link
              href="/book"
              className="py-3 px-6 rounded-full bg-[#183D2B] hover:bg-[#25482F] text-[#FFF9EA] font-bold text-xs sm:text-sm text-center shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-[#C49A43]" />
              <span>Launch Booking Wizard</span>
            </Link>

            <a
              href={`https://wa.me/91${settings.whatsappNumber}?text=Hello%20Sri%20Chakra%20Caterers,%20I%20would%20like%20to%20enquire%20about%20catering%20services.`}
              target="_blank"
              rel="noopener noreferrer"
              className="py-3 px-6 rounded-full bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold text-xs sm:text-sm text-center shadow-md transition-all flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Quick Chat</span>
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}
