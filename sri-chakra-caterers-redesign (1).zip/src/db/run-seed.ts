import { ensureDatabaseSeeded } from "./seed";
import { pool } from "./index";

async function main() {
  console.log("Seeding database...");
  const res = await ensureDatabaseSeeded();
  console.log("Seed result:", res);
  await pool.end();
}

main().catch((err) => {
  console.error("Seeding failed:", err);
  process.exit(1);
});
