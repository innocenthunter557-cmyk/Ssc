import { db } from "@/db";
import { siteSettings, packages, packageItems, packageCategoryRules, adminUsers } from "@/db/schema";
import { count, eq } from "drizzle-orm";
import crypto from "crypto";

export async function ensureDatabaseSeeded() {
  try {
    // Check if packages already exist
    const pkgCount = await db.select({ val: count() }).from(packages);
    if (Number(pkgCount[0]?.val ?? 0) > 0) {
      return { success: true, message: "Database already seeded" };
    }

    // 1. Seed Site Settings
    await db.insert(siteSettings).values({
      businessName: "Sri Chakra Caterers",
      tagline: "Deliciously Crafted. Perfectly Served.",
      secondaryTagline: "Good Food. Happy People. Blessed Occasions.",
      primaryPhone: "9705075113",
      whatsappNumber: "9705075113",
      alternatePhone: "9000226809",
      phoneConflictFlagged: true,
      phoneConflictNote: "Original posters advertise 9705075113; previous project reference had 9000226809. Configured primary as 9705075113. Needs owner confirmation before changing.",
      email: "contact@srichakracaterers.com",
      instagram: "@srichakracaterers_",
      primaryLocation: "Kothapet and Meerpet, Hyderabad, Telangana",
      serviceAreas: [
        "Kothapet", "Meerpet", "LB Nagar", "Dilsukhnagar", "Saroornagar",
        "Karmanghat", "Vanasthalipuram", "Hayathnagar", "Uppal", "Malakpet",
        "Gachibowli", "Madhapur", "Kondapur", "Kukatpally", "Secunderabad", "Hyderabad & Secunderabad (All Areas)"
      ],
      bananaLeafExtraPricePerPlate: null, // "Price to be confirmed" until owner specifies
      homeDeliveryAdvanceDays: 3,
      standardAdvanceDays: 2,
    });

    // 2. Seed Default Admin User (Password hashed with SHA-256 for secure demo admin: srichakra / srichakra@2026)
    const adminPasswordHash = crypto.createHash("sha256").update("srichakra@2026").digest("hex");
    await db.insert(adminUsers).values({
      username: "admin",
      passwordHash: adminPasswordHash,
      fullName: "Sri Chakra Caterers Administrator",
      role: "owner",
    });

    // 3. Seed Packages from Original Posters
    // Package A: Special Home-Delivery Feast
    const [pkgHomeDelivery] = await db.insert(packages).values({
      code: "home_delivery_25",
      titleEn: "Special Home-Delivery Feast",
      titleTe: "ప్రత్యేక హోమ్ డెలివరీ విందు (25 మందికి)",
      titleHi: "स्पेशल होम डिलीवरी दावत (25 लोगों के लिए)",
      badge: "Fixed Package",
      dietType: "veg",
      pricingType: "fixed_package",
      price: "4500.00",
      fixedMemberCount: 25,
      minGuests: 25,
      description: "Authentic traditional Telugu feast packaged fresh for home delivery across Hyderabad. Fixed price ₹4,500 for exactly 25 members.",
      shortHighlights: ["Fixed ₹4,500 for 25 Members", "Home Delivery across Hyderabad", "Order 2–3 Days in Advance", "Ghee & Pure Telugu Flavours"],
      includedServices: ["Home Delivery (Hyderabad)", "Food packed in secure food-grade carriers", "Papad & Pickle separate packs", "Ghee & Curd inclusions"],
      optionalServices: ["Extra member quotation on request", "Disposable plates & leaf covers (on request)"],
      posterNotes: "Explicitly ₹4,500 for 25 members on poster. Order 2–3 days in advance. Contact advertised: 9705075113.",
      advanceOrderDays: 3,
      isCustomizable: false,
      imageUrl: "/images/home-delivery-feast.jpg",
      displayOrder: 1,
    }).returning();

    // Package B: Vegetarian Special - ₹280
    const [pkgVeg280] = await db.insert(packages).values({
      code: "veg_special_280",
      titleEn: "Vegetarian Special Menu",
      titleTe: "వెజ్ స్పెషల్ భోజనం",
      titleHi: "शाकाहारी स्पेशल मेनू",
      badge: "Pure Vegetarian",
      dietType: "veg",
      pricingType: "per_plate",
      price: "280.00",
      minGuests: 25,
      description: "Complete 20-dish traditional South Indian pure vegetarian feast prepared with premium Gold Drop Oil and Vijaya Ghee.",
      shortHighlights: ["20 Complete Traditional Dishes", "Gold Drop Oil & Vijaya Ghee", "Plates & Glasses Included", "Pure Vegetarian Delight"],
      includedServices: ["Plates, Glasses & Accessories Included", "Food Warmers & Display", "Experienced Serving Staff", "Drinking Water (250ml bottles)"],
      optionalServices: ["Traditional Arati Aaku (Fresh Banana Leaf) serving", "Live Welcome Drink Counter"],
      posterNotes: "Poster claims: Only vegetarian, Plates, glasses and other accessories included, Gold Drop Oil and Vijaya Ghee mentioned, Excellent service guaranteed.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/veg-grand-feast.jpg",
      displayOrder: 2,
    }).returning();

    // Package C: Non-Veg Budget Menu - ₹299
    const [pkgNonveg299] = await db.insert(packages).values({
      code: "nonveg_budget_299",
      titleEn: "Non-Veg Budget Menu",
      titleTe: "నాన్-వెజ్ బడ్జెట్ మెనూ",
      titleHi: "नॉन-वेज बजट मेनू",
      badge: "Budget Friendly",
      dietType: "non-veg",
      pricingType: "per_plate",
      price: "299.00",
      minGuests: 30,
      description: "Value-packed Hyderabadi celebration feast featuring fragrant Chicken Biryani, Paneer Masala, Rumali Roti, and classic accompaniments.",
      shortHighlights: ["Aromatic Chicken Biryani", "Rumali Roti / Pulka", "Paneer Masala & Salan", "14 Total Courses"],
      includedServices: ["Buffet setup & Chafing dishes", "Plates & Glasses", "Water service", "Serving personnel"],
      optionalServices: ["Mutton upgrade quotation", "Live starter counters", "Arati Aaku leaf service"],
      posterNotes: "Displays ₹299 per plate exactly as per original poster.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/hyderabadi-biryani-feast.jpg",
      displayOrder: 3,
    }).returning();

    // Package D: Non-Veg Standard Menu - ₹399
    const [pkgNonveg399] = await db.insert(packages).values({
      code: "nonveg_standard_399",
      titleEn: "Non-Veg Standard Menu",
      titleTe: "నాన్-వెజ్ స్టాండర్డ్ మెనూ",
      titleHi: "नॉन-वेज स्टैंडर्ड मेनू",
      badge: "Mutton Dum Biryani",
      dietType: "non-veg",
      pricingType: "per_plate",
      price: "399.00",
      minGuests: 30,
      description: "Our signature Hyderabadi wedding buffet with Royal Mutton Dum Biryani, Chicken Curry, Veg Starter, and Veg Biryani/Bagara Rice.",
      shortHighlights: ["Royal Mutton Dum Biryani", "Spicy Chicken Curry", "Veg Starter Choice", "Bagara Rice & Rumali Roti"],
      includedServices: ["Plates, Glasses & Tissues", "Full Buffet setup & Chafing vessels", "Dedicated service team", "Water service"],
      optionalServices: ["Ice Cream & Sweet Paan upgrade", "Arati Aaku traditional seating"],
      posterNotes: "Displays ₹399 per plate. Includes 17 items with slash choices for starters, rotis, and curries.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/hyderabadi-biryani-feast.jpg",
      displayOrder: 4,
    }).returning();

    // Package E: Non-Veg Silver Menu - ₹479
    const [pkgNonveg479] = await db.insert(packages).values({
      code: "nonveg_silver_479",
      titleEn: "Non-Veg Silver Luxury Menu",
      titleTe: "నాన్-వెజ్ సిల్వర్ లగ్జరీ మెనూ",
      titleHi: "नॉन-वेज सिल्वर लग्जरी मेनू",
      badge: "All-Inclusive Luxury",
      dietType: "non-veg",
      pricingType: "per_plate",
      price: "479.00",
      minGuests: 30,
      description: "Grand multi-course banquet with Mutton Dum Biryani, Non-Veg Starter (Chicken 65/Apollo Fish), Chicken Curry, Sweet Paan, Ice Cream, and all-inclusive service.",
      shortHighlights: ["Non-Veg Starter (Chicken 65 / Apollo Fish)", "Mutton Dum Biryani & Chicken Curry", "Sweet Paan & Ice Cream Included", "All-Inclusive Service & Transport"],
      includedServices: ["Plates, Glasses & Tissues", "Complete Catering Service Staff", "Transport within Hyderabad", "Water Bottle Included", "Ice Cream & Sweet Paan"],
      optionalServices: ["Live Dosa / Jalebi counter", "Traditional Banana Leaf seating"],
      posterNotes: "Displays ₹479 per plate. Poster lists plates, glasses, tissues, service and transport under an all-inclusive banner.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/wedding-catering-setup.jpg",
      displayOrder: 5,
    }).returning();

    // Package F: Vegetarian Grand Menu - ₹399 (Custom Category Selection)
    const [pkgVegGrand399] = await db.insert(packages).values({
      code: "veg_grand_399",
      titleEn: "Vegetarian Grand Menu (Custom Selection)",
      titleTe: "వెజిటేరియన్ గ్రాండ్ మెనూ (కస్టమ్ ఎంపిక)",
      titleHi: "वेजिटेरियन ग्रैंड मेनू (कस्टम चयन)",
      badge: "Custom Selectable",
      dietType: "veg",
      pricingType: "per_plate",
      price: "399.00",
      minGuests: 25,
      description: "Our premier customisable vegetarian banquet. Choose your own dishes across 9 categories with exact selection limits, plus 13 included staples.",
      shortHighlights: ["Select 1 Welcome Drink & 2 Starters", "Choose Flavoured Rice, Bread & Fries", "Curry, Paneer/Mushroom & Pappu choices", "2 Royal Sweets + Ice Cream"],
      includedServices: ["Plain Rice, Sambar/Rasam & Chutney", "Raita, Salad & Crispy Papad", "Ice Cream", "Chinese Special Dish (Flagged: Chefian Dish on poster)", "Plates, Spoons, Bowls & Tissues", "Water Bottle (200 ml)"],
      optionalServices: ["Traditional Arati Aaku (Banana Leaf) feast", "Live Tawa Roti Counter"],
      posterNotes: "Category-selection package ₹399 per plate. Poster text has 'Chefian Dish' - flagged for owner confirmation.",
      advanceOrderDays: 2,
      isCustomizable: true,
      imageUrl: "/images/arati-aaku-feast.jpg",
      displayOrder: 6,
    }).returning();

    // Package G: Standard Vegetarian Menu - ₹260
    const [pkgVegStandard260] = await db.insert(packages).values({
      code: "veg_standard_260",
      titleEn: "Standard Vegetarian Menu",
      titleTe: "స్టాండర్డ్ వెజిటేరియన్ మెనూ",
      titleHi: "स्टैंडर्ड शाकाहारी मेनू",
      badge: "Popular Traditional",
      dietType: "veg",
      pricingType: "per_plate",
      price: "260.00",
      minGuests: 25,
      description: "Beloved traditional Telugu feast with Bobbatlu/Kesari, Paneer Butter Masala, Bagara Rice, Mirchi Bajji, and full service.",
      shortHighlights: ["Bobbatlu / Ravva Kesari Sweet Choice", "Paneer Butter Masala & Bagara", "Mirchi Bajji & Fryums", "Plates & Glasses Included"],
      includedServices: ["Service included", "Plates and Glasses provided", "Chafing dish setup"],
      optionalServices: ["Arati Aaku leaf service", "Ice cream counter"],
      posterNotes: "₹260 per plate. Poster says service included and plates and glasses provided. Slash alternatives subject to owner confirmation.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/veg-grand-feast.jpg",
      displayOrder: 7,
    }).returning();

    // Package H: Basic Menu 1 - ₹220
    const [pkgVegBasic220] = await db.insert(packages).values({
      code: "veg_basic1_220",
      titleEn: "Basic Vegetarian Menu 1",
      titleTe: "బేసిక్ వెజిటేరియన్ మెనూ 1",
      titleHi: "बेसिक शाकाहारी मेनू 1",
      badge: "Value Traditional",
      dietType: "veg",
      pricingType: "per_plate",
      price: "220.00",
      minGuests: 30,
      description: "Wholesome 12-course Telugu celebration meal with Basmati Bagara, Alu Kurma/Vankaya Masala, Veg Fry, Dal, and Sambar.",
      shortHighlights: ["Basmati Bagara Rice", "Sweet Choice (Kesari/Bobbattu)", "Mirchi Bajji & Dal/Sambar", "Service & Plates Included"],
      includedServices: ["Plates and glasses provided", "Service included"],
      optionalServices: ["Roti / Poori add-on", "Arati Aaku leaf serving"],
      posterNotes: "₹220 per plate. Poster states plates and glasses are provided under service included.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/veg-grand-feast.jpg",
      displayOrder: 8,
    }).returning();

    // Package I: Basic Menu 2 - ₹200
    const [pkgVegBasic200] = await db.insert(packages).values({
      code: "veg_basic2_200",
      titleEn: "Basic Vegetarian Menu 2",
      titleTe: "బేసిక్ వెజిటేరియన్ మెనూ 2",
      titleHi: "बेसिक शाकाहारी मेनू 2",
      badge: "Essential Feast",
      dietType: "veg",
      pricingType: "per_plate",
      price: "200.00",
      minGuests: 30,
      description: "Essential 10-dish traditional feast with Sona Bagara Rice, traditional Curry, Dal, Sambar, Roti Chutney, and Sweet.",
      shortHighlights: ["Sona Bagara Rice", "Traditional Telugu Curries", "Sweet Choice & Fryums", "Plates & Glasses Provided"],
      includedServices: ["Plates and glasses provided", "Service included"],
      optionalServices: ["Starters add-on", "Arati Aaku leaf serving"],
      posterNotes: "₹200 per plate. Plates and glasses provided under service included.",
      advanceOrderDays: 2,
      isCustomizable: false,
      imageUrl: "/images/veg-grand-feast.jpg",
      displayOrder: 9,
    }).returning();

    // 4. Seed Package Items
    // A. Home Delivery Items (10 items)
    const homeDeliveryItems = [
      { name: "Rice", te: "అన్నం", cat: "staple" },
      { name: "Pappu", te: "పప్పు", cat: "dal" },
      { name: "Sambar", te: "సాంబార్", cat: "gravy" },
      { name: "Curry", te: "కూర", cat: "curry" },
      { name: "Hot / Karam", te: "హాట్ / కారం", cat: "hot" },
      { name: "Sweet", te: "స్వీట్", cat: "sweet" },
      { name: "Pickle", te: "ఊరగాయ", cat: "condiment" },
      { name: "Papad", te: "అప్పడం", cat: "crisp" },
      { name: "Curd", te: "పెరుగు", cat: "curd" },
      { name: "Ghee", te: "నెయ్యి", cat: "ghee" },
    ];
    for (let i = 0; i < homeDeliveryItems.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgHomeDelivery.id,
        itemNumber: i + 1,
        itemNameEn: homeDeliveryItems[i].name,
        itemNameTe: homeDeliveryItems[i].te,
        categoryGroup: homeDeliveryItems[i].cat,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // B. Veg Special ₹280 Items (20 items)
    const veg280Items = [
      { name: "Sweet Gulab Jamun", te: "గులాబ్ జామూన్" },
      { name: "Mirchi Bajji", te: "మిర్చి బజ్జి" },
      { name: "Pulihora", te: "పులిహోర" },
      { name: "Poori", te: "పూరి" },
      { name: "Paneer Butter Masala", te: "పనీర్ బటర్ మసాలా" },
      { name: "Veg Biryani", te: "వెజ్ బిర్యానీ" },
      { name: "Dal", te: "దాల్" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Guttivankaya Masala", te: "గుత్తివంకాయ మసాలా" },
      { name: "Gobi Fry 65", te: "గోబీ ఫ్రై 65" },
      { name: "Pickle", te: "ఊరగాయ" },
      { name: "Fresh Pickle", te: "రోటీ పచ్చడి" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Raitha", te: "రైతా" },
      { name: "White Rice", te: "తెల్ల అన్నం" },
      { name: "Green Salad", te: "గ్రీన్ సలాడ్" },
      { name: "Mouth Freshener", te: "మౌత్ ఫ్రెషనర్" },
      { name: "Ice Cream", te: "ఐస్ క్రీమ్" },
      { name: "Papad", te: "అప్పడం" },
      { name: "Water Bottle (250 ml)", te: "నీళ్ల బాటిల్ (250 ml)" },
    ];
    for (let i = 0; i < veg280Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgVeg280.id,
        itemNumber: i + 1,
        itemNameEn: veg280Items[i].name,
        itemNameTe: veg280Items[i].te,
        categoryGroup: "veg_special",
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // C. Non-Veg Budget ₹299 Items (14 items)
    const nonveg299Items = [
      { name: "Sweet", te: "స్వీట్" },
      { name: "Rumali Roti / Pulka", te: "రుమాలి రోటీ / పుల్కా", alt: true, group: "bread" },
      { name: "Paneer Masala", te: "పనీర్ మసాలా" },
      { name: "Chicken Biryani", te: "చికెన్ బిర్యానీ" },
      { name: "Mirchi Ka Salan", te: "మిర్చి కా సాలన్" },
      { name: "Dal", te: "దాల్" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Plain Rice", te: "సాదా అన్నం" },
      { name: "Raitha", te: "రైతా" },
      { name: "One Chutney", te: "చట్నీ" },
      { name: "Papad", te: "అప్పడం" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Mouth Freshener", te: "మౌత్ ఫ్రెషనర్" },
      { name: "Water", te: "నీరు" },
    ];
    for (let i = 0; i < nonveg299Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgNonveg299.id,
        itemNumber: i + 1,
        itemNameEn: nonveg299Items[i].name,
        itemNameTe: nonveg299Items[i].te,
        categoryGroup: "nonveg_budget",
        isSelectableAlternative: !!nonveg299Items[i].alt,
        alternativeGroup: nonveg299Items[i].group,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // D. Non-Veg Standard ₹399 Items (17 items)
    const nonveg399Items = [
      { name: "Sweet", te: "స్వీట్" },
      { name: "Veg Manchurian / Cut Mirchi / Corn Samosa", te: "వెజ్ మంచూరియా / కట్ మిర్చి / కార్న్ సమోసా", alt: true, group: "starter" },
      { name: "Rumali Roti / Pulka", te: "రుమాలి రోటీ / పుల్కా", alt: true, group: "bread" },
      { name: "Paneer Masala / Chole Masala", te: "పనీర్ మసాలా / చోలే మసాలా", alt: true, group: "veg_curry" },
      { name: "Mutton Dum Biryani", te: "మటన్ దమ్ బిర్యానీ" },
      { name: "Mirchi Ka Salan", te: "మిర్చి కా సాలన్" },
      { name: "Dal", te: "దాల్" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Chicken Curry", te: "చికెన్ కర్రీ" },
      { name: "Veg Biryani / Bagara Rice", te: "వెజ్ బిర్యానీ / బగారా రైస్", alt: true, group: "flavoured_rice" },
      { name: "Plain Rice", te: "సాదా అన్నం" },
      { name: "Raitha", te: "రైతా" },
      { name: "Chutney", te: "చట్నీ" },
      { name: "Papad", te: "అప్పడం" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Mouth Freshener", te: "మౌత్ ఫ్రెషనర్" },
      { name: "Water", te: "నీరు" },
    ];
    for (let i = 0; i < nonveg399Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgNonveg399.id,
        itemNumber: i + 1,
        itemNameEn: nonveg399Items[i].name,
        itemNameTe: nonveg399Items[i].te,
        categoryGroup: "nonveg_standard",
        isSelectableAlternative: !!nonveg399Items[i].alt,
        alternativeGroup: nonveg399Items[i].group,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // E. Non-Veg Silver ₹479 Items (19 items)
    const nonveg479Items = [
      { name: "Sweet", te: "స్వీట్" },
      { name: "Veg Manchurian / Cut Mirchi / Corn Samosa", te: "వెజ్ మంచూరియా / కట్ మిర్చి / కార్న్ సమోసా", alt: true, group: "veg_starter" },
      { name: "Chicken Manchurian / Chilli Chicken / Chicken 65 / Apollo Fish", te: "చికెన్ మంచూరియా / చిల్లీ చికెన్ / చికెన్ 65 / అపోలో ఫిష్", alt: true, group: "nonveg_starter" },
      { name: "Rumali Roti / Pulka", te: "రుమాలి రోటీ / పుల్కా", alt: true, group: "bread" },
      { name: "Paneer Masala / Chole Masala", te: "పనీర్ మసాలా / చోలే మసాలా", alt: true, group: "veg_curry" },
      { name: "Mutton Dum Biryani", te: "మటన్ దమ్ బిర్యానీ" },
      { name: "Mirchi Ka Salan", te: "మిర్చి కా సాలన్" },
      { name: "Dal", te: "దాల్" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Chicken Curry", te: "చికెన్ కర్రీ" },
      { name: "Veg Biryani / Bagara Rice", te: "వెజ్ బిర్యానీ / బగారా రైస్", alt: true, group: "flavoured_rice" },
      { name: "Plain Rice", te: "సాదా అన్నం" },
      { name: "Raitha", te: "రైతా" },
      { name: "Chutney", te: "చట్నీ" },
      { name: "Papad", te: "అప్పడం" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Sweet Paan", te: "స్వీట్ పాన్" },
      { name: "Water Bottle", te: "నీళ్ల బాటిల్" },
      { name: "Ice Cream", te: "ఐస్ క్రీమ్" },
    ];
    for (let i = 0; i < nonveg479Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgNonveg479.id,
        itemNumber: i + 1,
        itemNameEn: nonveg479Items[i].name,
        itemNameTe: nonveg479Items[i].te,
        categoryGroup: "nonveg_silver",
        isSelectableAlternative: !!nonveg479Items[i].alt,
        alternativeGroup: nonveg479Items[i].group,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // F. Veg Grand Menu ₹399 - Rules and Custom Choices
    // Category Rules
    const vegGrandRules = [
      { key: "welcome_drink", labelEn: "Welcome Drink", labelTe: "వెల్కమ్ డ్రింక్", req: 1, max: 1, order: 1 },
      { key: "starters", labelEn: "Starters", labelTe: "స్టార్టర్స్", req: 2, max: 2, order: 2 },
      { key: "flavoured_rice", labelEn: "Flavoured Rice", labelTe: "ఫ్లేవర్డ్ రైస్", req: 1, max: 1, order: 3 },
      { key: "bread", labelEn: "Bread", labelTe: "రోటీలు / పూరి", req: 1, max: 1, order: 4 },
      { key: "veg_fry", labelEn: "Vegetarian Fry", labelTe: "వెజ్ వేపుడు", req: 1, max: 1, order: 5 },
      { key: "veg_curry", labelEn: "Vegetarian Curry", labelTe: "వెజ్ కూర", req: 1, max: 1, order: 6 },
      { key: "paneer_mushroom", labelEn: "Paneer & Mushroom Curry", labelTe: "పనీర్ & మష్రూమ్ కర్రీ", req: 1, max: 1, order: 7 },
      { key: "dal_pappu", labelEn: "Daal / Pappu", labelTe: "పప్పు", req: 1, max: 1, order: 8 },
      { key: "sweets", labelEn: "Sweets", labelTe: "మిఠాయిలు", req: 2, max: 2, order: 9 },
    ];
    for (const rule of vegGrandRules) {
      await db.insert(packageCategoryRules).values({
        packageId: pkgVegGrand399.id,
        categoryKey: rule.key,
        categoryLabelEn: rule.labelEn,
        categoryLabelTe: rule.labelTe,
        requiredCount: rule.req,
        maxCount: rule.max,
        displayOrder: rule.order,
      });
    }

    // Veg Grand Dishes to select from:
    const vegGrandOptions = [
      // Welcome Drinks (6)
      { cat: "welcome_drink", name: "Orange Juice", te: "ఆరెంజ్ జ్యూస్" },
      { cat: "welcome_drink", name: "Fruit Punch", te: "ఫ్రూట్ పంచ్" },
      { cat: "welcome_drink", name: "Mint Mojito", te: "మింట్ మొజితో" },
      { cat: "welcome_drink", name: "Watermelon Mojito", te: "వాటర్‌మెలన్ మొజితో" },
      { cat: "welcome_drink", name: "Rose Milk", te: "రోజ్ మిల్క్" },
      { cat: "welcome_drink", name: "Blue Lagoon", te: "బ్లూ లగూన్" },

      // Starters (12)
      { cat: "starters", name: "Mirapakaaya Bajji", te: "మిరపకాయ బజ్జి" },
      { cat: "starters", name: "Mini Capsicum Bajji", te: "మినీ క్యాప్సికం బజ్జి" },
      { cat: "starters", name: "Perugu Vada", te: "పెరుగు వడ" },
      { cat: "starters", name: "Vada with Tomato Chutney", te: "టొమాటో చట్నీతో వడ" },
      { cat: "starters", name: "Crispy Sweet Corn", te: "క్రిస్పీ స్వీట్ కార్న్" },
      { cat: "starters", name: "Oriental Veg Spring Rolls", te: "వెజ్ స్ప్రింగ్ రోల్స్" },
      { cat: "starters", name: "Shanghai-Style Veg Manchurian", te: "వెజ్ మంచూరియా" },
      { cat: "starters", name: "Crispy Gobi 65", te: "క్రిస్పీ గోబీ 65" },
      { cat: "starters", name: "Royal Achari Paneer Tikka", te: "ఆచారీ పనీర్ టిక్కా" },
      { cat: "starters", name: "Creamy Malai Paneer Royale", te: "మలై పనీర్ రాయల్" },
      { cat: "starters", name: "Schezwan Chilli Paneer", te: "షెజ్వాన్ చిల్లీ పనీర్" },
      { cat: "starters", name: "Fiery Chilli Mushroom", te: "చిల్లీ మష్రూమ్" },

      // Flavoured Rice (6)
      { cat: "flavoured_rice", name: "Pulihora", te: "పులిహోర" },
      { cat: "flavoured_rice", name: "Coconut Rice", te: "కొబ్బరి అన్నం" },
      { cat: "flavoured_rice", name: "Kaju Bagara Rice", te: "కాజు బగారా రైస్" },
      { cat: "flavoured_rice", name: "Jeera Rice", te: "జీరా రైస్" },
      { cat: "flavoured_rice", name: "Gongura Rice", te: "గోంగూర రైస్" },
      { cat: "flavoured_rice", name: "Muddapappu Avakai Annam", te: "ముద్దపప్పు ఆవకాయ అన్నం" },

      // Bread (6)
      { cat: "bread", name: "Poori", te: "పూరి" },
      { cat: "bread", name: "Methi Poori", te: "మేథీ పూరి" },
      { cat: "bread", name: "Rumali Roti", te: "రుమాలి రోటీ" },
      { cat: "bread", name: "Plain Roti", te: "ప్లెయిన్ రోటీ" },
      { cat: "bread", name: "Chapati", te: "చపాతీ" },
      { cat: "bread", name: "Naan", te: "నాన్" },

      // Vegetarian Fry (7)
      { cat: "veg_fry", name: "Aratikaya Fry", te: "అరటికాయ వేపుడు" },
      { cat: "veg_fry", name: "Dondakaya Fry", te: "దొండకాయ వేపుడు" },
      { cat: "veg_fry", name: "Vankaya Fry", te: "వంకాయ వేపుడు" },
      { cat: "veg_fry", name: "Beans & Carrot Fry", te: "బీన్స్ క్యారెట్ వేపుడు" },
      { cat: "veg_fry", name: "Bendakaya Kaju Fry", te: "బెండకాయ కాజు వేపుడు" },
      { cat: "veg_fry", name: "Aloo Jeera Fry", te: "ఆలూ జీరా వేపుడు" },
      { cat: "veg_fry", name: "Dondakaya Kaju Pakodi Fry", te: "దొండకాయ కాజు పకోడీ ఫ్రై" },

      // Vegetarian Curry (7)
      { cat: "veg_curry", name: "Gutti Vankaya Kura", te: "గుత్తి వంకాయ కూర" },
      { cat: "veg_curry", name: "Tomato Mulakkada Kura", te: "టొమాటో ములక్కాడ కూర" },
      { cat: "veg_curry", name: "Aloo Tomato Kura", te: "ఆలూ టొమాటో కూర" },
      { cat: "veg_curry", name: "Mix Veg Curry", te: "మిక్స్డ్ వెజ్ కూర" },
      { cat: "veg_curry", name: "Aloo Kurma", te: "ఆలూ కుర్మా" },
      { cat: "veg_curry", name: "Gobi Masala", te: "గోబీ మసాలా" },
      { cat: "veg_curry", name: "Vankaya Tomato Kura", te: "వంకాయ టొమాటో కూర" },

      // Paneer & Mushroom Curry (9)
      { cat: "paneer_mushroom", name: "Signature Butter Paneer Masala", te: "బటర్ పనీర్ మసాలా" },
      { cat: "paneer_mushroom", name: "Kadai-Style Paneer Supreme", te: "కడాయ్ పనీర్" },
      { cat: "paneer_mushroom", name: "Creamy Malai Paneer Royale", te: "మలై పనీర్ రాయల్" },
      { cat: "paneer_mushroom", name: "Paneer Kaju Kurma", te: "పనీర్ కాజు కుర్మా" },
      { cat: "paneer_mushroom", name: "Palak Paneer", te: "పాలక్ పనీర్" },
      { cat: "paneer_mushroom", name: "Matar Kofta", te: "మటర్ కోఫ్తా" },
      { cat: "paneer_mushroom", name: "Hyderabad Methi Chaman", te: "హైదరాబాద్ మేథీ చమన్" },
      { cat: "paneer_mushroom", name: "Royal Kaju Mushroom Curry", te: "కాజు మష్రూమ్ కర్రీ" },
      { cat: "paneer_mushroom", name: "Mushroom Fry Masala", te: "మష్రూమ్ ఫ్రై మసాలా" },

      // Daal / Pappu (5)
      { cat: "dal_pappu", name: "Gongura Pappu", te: "గోంగూర పప్పు" },
      { cat: "dal_pappu", name: "Mamidikaya Pappu", te: "మామిడికాయ పప్పు" },
      { cat: "dal_pappu", name: "Tomato Pappu", te: "టొమాటో పప్పు" },
      { cat: "dal_pappu", name: "Thotakura Pappu", te: "తోటకూర పప్పు" },
      { cat: "dal_pappu", name: "Dosakaya Pappu", te: "దోసకాయ పప్పు" },

      // Sweets (10)
      { cat: "sweets", name: "Gulab Jamun", te: "గులాబ్ జామూన్" },
      { cat: "sweets", name: "Double Ka Meetha", te: "డబుల్ కా మీఠా" },
      { cat: "sweets", name: "Semiya Payasam", te: "సేమియా పాయసం" },
      { cat: "sweets", name: "Paramannam", te: "పరమాన్నం" },
      { cat: "sweets", name: "Carrot Halwa", te: "క్యారెట్ హల్వా" },
      { cat: "sweets", name: "Boorelu", te: "బూరెలు" },
      { cat: "sweets", name: "Kala Jamun", te: "కాలా జామూన్" },
      { cat: "sweets", name: "Rava Kesari", te: "రవ్వ కేసరి" },
      { cat: "sweets", name: "Qurbani Ka Meetha", te: "ఖుబానీ కా మీఠా" },
      { cat: "sweets", name: "Bellam Pongal", te: "బెల్లం పొంగల్" },
    ];

    let grandItemIndex = 1;
    for (const opt of vegGrandOptions) {
      await db.insert(packageItems).values({
        packageId: pkgVegGrand399.id,
        itemNumber: grandItemIndex++,
        itemNameEn: opt.name,
        itemNameTe: opt.te,
        categoryGroup: opt.cat,
        isMandatoryIncluded: false, // Customer selects this
        displayOrder: grandItemIndex,
      });
    }

    // Add Mandatory Included items for Veg Grand 399
    const vegGrandMandatory = [
      { name: "Plain Rice", te: "సాదా అన్నం" },
      { name: "Sambar / Rasam", te: "సాంబార్ / రసం" },
      { name: "Chutney", te: "చట్నీ" },
      { name: "Raita", te: "రైతా" },
      { name: "Salad", te: "సలాడ్" },
      { name: "Papad", te: "అప్పడం" },
      { name: "Ice Cream", te: "ఐస్ క్రీమ్" },
      { name: "Chefian Dish (Chinese dish flagged for owner verification)", te: "చైనీస్ స్పెషల్ డిష్ (షెఫియన్ డిష్)", note: "Original poster reads 'Chefian Dish' - flagged for owner confirmation" },
      { name: "Plates, Spoons & Bowls", te: "ప్లేట్లు, స్పూన్లు, గిన్నెలు" },
      { name: "Tissues & Napkins", te: "టిష్యూలు" },
      { name: "Water Bottle (200 ml)", te: "వాటర్ బాటిల్ (200 ml)" },
    ];
    for (const inc of vegGrandMandatory) {
      await db.insert(packageItems).values({
        packageId: pkgVegGrand399.id,
        itemNumber: grandItemIndex++,
        itemNameEn: inc.name,
        itemNameTe: inc.te,
        categoryGroup: "included",
        ownerNote: inc.note,
        isMandatoryIncluded: true,
        displayOrder: grandItemIndex,
      });
    }

    // G. Standard Veg Menu ₹260 (14 items)
    const veg260Items = [
      { name: "Bobbatlu / Ravva Kesari / Double Ka Mitai / Jamoon", te: "బొబ్బట్లు / రవ్వ కేసరి / డబుల్ కా మీఠా / జామూన్", alt: true, group: "sweet" },
      { name: "Rumali Roti / Pulka", te: "రుమాలి రోటీ / పుల్కా", alt: true, group: "bread" },
      { name: "Paneer Butter Masala", te: "పనీర్ బటర్ మసాలా" },
      { name: "Bagara", te: "బగారా" },
      { name: "Alu Kurma / Vankaya / Mirchi Masala", te: "ఆలూ కుర్మా / వంకాయ / మిర్చి మసాలా", alt: true, group: "curry" },
      { name: "White Rice", te: "తెల్ల అన్నం" },
      { name: "Roti Chutney", te: "రోటీ చట్నీ" },
      { name: "Veg Fry / Veg 65", te: "వెజ్ ఫ్రై / వెజ్ 65", alt: true, group: "fry" },
      { name: "Dal", te: "దాల్" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Mirchi Bajji", te: "మిర్చి బజ్జి" },
      { name: "Raitha", te: "రైతా" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Fryums", te: "ఫ్రైయమ్స్" },
    ];
    for (let i = 0; i < veg260Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgVegStandard260.id,
        itemNumber: i + 1,
        itemNameEn: veg260Items[i].name,
        itemNameTe: veg260Items[i].te,
        categoryGroup: "veg_standard",
        isSelectableAlternative: !!veg260Items[i].alt,
        alternativeGroup: veg260Items[i].group,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // H. Basic Menu 1 ₹220 (12 items)
    const veg220Items = [
      { name: "Ravva Kesari / Semaya Kesari / Bobbattu", te: "రవ్వ కేసరి / సేమ్యా కేసరి / బొబ్బట్టు", alt: true, group: "sweet" },
      { name: "Bagara (Basmathi)", te: "బగారా (బాస్మతి)" },
      { name: "Alu Kurma / Vankaya / Mirchi Masala", te: "ఆలూ కుర్మా / వంకాయ / మిర్చి మసాలా", alt: true, group: "curry" },
      { name: "White Rice", te: "తెల్ల అన్నం" },
      { name: "Veg Fry / Veg 65", te: "వెజ్ ఫ్రై / వెజ్ 65", alt: true, group: "fry" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Mirchi Bajji", te: "మిర్చి బజ్జి" },
      { name: "Raitha", te: "రైతా" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Fryums", te: "ఫ్రైయమ్స్" },
      { name: "Roti Chutney", te: "రోటీ చట్నీ" },
      { name: "Dal", te: "దాల్" },
    ];
    for (let i = 0; i < veg220Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgVegBasic220.id,
        itemNumber: i + 1,
        itemNameEn: veg220Items[i].name,
        itemNameTe: veg220Items[i].te,
        categoryGroup: "veg_basic1",
        isSelectableAlternative: !!veg220Items[i].alt,
        alternativeGroup: veg220Items[i].group,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    // I. Basic Menu 2 ₹200 (10 items)
    const veg200Items = [
      { name: "Ravva Kesari / Semaya Kesari / Bobbattu", te: "రవ్వ కేసరి / సేమ్యా కేసరి / బొబ్బట్టు", alt: true, group: "sweet" },
      { name: "Sona Bagara", te: "సోనా బగారా" },
      { name: "Alu Kurma / Vankaya / Mirchi Masala", te: "ఆలూ కుర్మా / వంకాయ / మిర్చి మసాలా", alt: true, group: "curry" },
      { name: "White Rice", te: "తెల్ల అన్నం" },
      { name: "Raitha", te: "రైతా" },
      { name: "Sambar", te: "సాంబార్" },
      { name: "Curd", te: "పెరుగు" },
      { name: "Fryums", te: "ఫ్రైయమ్స్" },
      { name: "Roti Chutney", te: "రోటీ చట్నీ" },
      { name: "Dal", te: "దాల్" },
    ];
    for (let i = 0; i < veg200Items.length; i++) {
      await db.insert(packageItems).values({
        packageId: pkgVegBasic200.id,
        itemNumber: i + 1,
        itemNameEn: veg200Items[i].name,
        itemNameTe: veg200Items[i].te,
        categoryGroup: "veg_basic2",
        isSelectableAlternative: !!veg200Items[i].alt,
        alternativeGroup: veg200Items[i].group,
        isMandatoryIncluded: true,
        displayOrder: i + 1,
      });
    }

    return { success: true, message: "Database successfully seeded with all 8 original packages and settings" };
  } catch (error) {
    console.error("Seeding error:", error);
    return { success: false, error: String(error) };
  }
}
